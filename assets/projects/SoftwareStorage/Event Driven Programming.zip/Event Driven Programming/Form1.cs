﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using Microsoft.VisualBasic;
using System.Text.RegularExpressions;

namespace Unit_16_Event_Driven_Programming
{
    public partial class Hardware : Form
    {
        string Font;
        double totalcost = 0;
        public Hardware()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (textBox2.Visible = false)
            {
                textBox2.Text = "";
            }
            comboBox1.Items.Add("AMD FX 8350AMD3 = £164.99");
            comboBox1.Items.Add("ASUS FX-8370 Black Edition = £179.99");
            comboBox1.Items.Add("AMD A10 7860K FM2+ = £99.99");
            comboBox1.Items.Add("AMD WRAITH HK A10 7890K = £139.99");

            comboBox2.Items.Add("MSI Geforce GTX 1060 = £294.99");
            comboBox2.Items.Add("ASUS Gefprce GTX 1080 = £669.99");
            comboBox2.Items.Add("EVGA Geforce GTX 950 SC = £137.98");
            comboBox2.Items.Add("ASUS Geforce GTX 750 Ti = £114.99");

            comboBox3.Items.Add("4GB = £18.99");
            comboBox3.Items.Add("8GB = £39.99");
            comboBox3.Items.Add("16GB = £47.99");

            comboBox4.Items.Add("SAMSUNG 850 EVO 250GB SSD = £74.99");
            comboBox4.Items.Add("SAMSUNG 850 EVO 500GB SSD = £132.99");
            comboBox4.Items.Add("SAMSUNG 850 EVO 120GB SSD = £49.97");
            comboBox4.Items.Add("WD MAINSTREAM 1TB Hard Drive = £49.99");

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

            listBox1.Items.Add(comboBox1.SelectedItem);
            if (comboBox1.SelectedIndex== 0)//1st item in list
            {
                totalcost = totalcost + 164.99;
                textBox1.Text = Convert.ToString("£" + totalcost);
            }
            if (comboBox1.SelectedIndex == 1)//2nd item in list
            {
                totalcost = totalcost + 179.99;
                textBox1.Text = Convert.ToString("£" + totalcost);
            }
            if (comboBox1.SelectedIndex == 2)//3rd item in list
            {
                totalcost = totalcost + 99.99;
                textBox1.Text = Convert.ToString("£" + totalcost);
            }
            if (comboBox1.SelectedIndex == 3)//4th item in list
            {
                totalcost = totalcost + 139.99;//5th item in list
                textBox1.Text = Convert.ToString("£" + totalcost);
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

            listBox1.Items.Add(comboBox2.SelectedItem);
            if (comboBox2.SelectedIndex == 0)//1st item in list
            {
                totalcost = totalcost + 294.99;
                textBox1.Text = Convert.ToString("£" + totalcost);
            }
            if (comboBox2.SelectedIndex == 1)//2nd item in list
            {
                totalcost = totalcost + 669.99;
                textBox1.Text = Convert.ToString("£" + totalcost);
            }
            if (comboBox2.SelectedIndex == 2)//3rd item in list
            {
                totalcost = totalcost + 137.98;
                textBox1.Text = Convert.ToString("£" + totalcost);
            }
            if (comboBox2.SelectedIndex == 3)//4th item in list
            {
                totalcost = totalcost + 114.99;//5th item in list
                textBox1.Text = Convert.ToString("£" + totalcost);
            }
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox1.Items.Add(comboBox3.SelectedItem);
            if (comboBox3.SelectedIndex == 0)//1st item in list
            {
                totalcost = totalcost + 18.99;
                textBox1.Text = Convert.ToString("£" + totalcost);
            }
            if (comboBox3.SelectedIndex == 1)//2nd item in list
            {
                totalcost = totalcost + 39.99;
                textBox1.Text = Convert.ToString("£" + totalcost);
            }
            if (comboBox3.SelectedIndex == 2)//3rd item in list
            {
                totalcost = totalcost + 47.99;
                textBox1.Text = Convert.ToString("£" + totalcost);
            }

        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox1.Items.Add(comboBox4.SelectedItem);
            if (comboBox3.SelectedIndex == 0)//1st item in list
            {
                totalcost = totalcost + 74.99;
                textBox1.Text = Convert.ToString("£" + totalcost);
            }
            if (comboBox3.SelectedIndex == 1)//2nd item in list
            {
                totalcost = totalcost + 132.99;
                textBox1.Text = Convert.ToString("£" + totalcost);
            }
            if (comboBox3.SelectedIndex == 2)//3rd item in list
            {
                totalcost = totalcost + 49.97;
                textBox1.Text = Convert.ToString("£" + totalcost);
            }
            if (comboBox3.SelectedIndex == 3)//4th item in list
            {
                totalcost = totalcost + 49.99;
                textBox1.Text = Convert.ToString("£" + totalcost);
            }
        }

        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {
            if(radioButton6.Checked==true)
            {
                listBox1.Items.Add("PC");
            }
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void radioButton7_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton7.Checked == true)
            {
                listBox1.Items.Add("MAC");
            }
        }

        private void radioButton8_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton8.Checked == true)
            {
                listBox1.Items.Add("TABLET");
            }
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            string firstname, surname, email, mobile_number, address;

            firstname = Interaction.InputBox("Customer's First Name", "Customer Details");
            surname = Interaction.InputBox("Customer's Surname", "Customer Details");
            email = Interaction.InputBox("Customer's Email Address", "Customer Details");
            mobile_number = Interaction.InputBox("Customer's Mobile Number", "Customer Details");
            address = Interaction.InputBox("Customer's Address", "Customer Details");

            string S1 = "";
            int listsize, listcount = 0;
            listsize = listBox1.Items.Count;
            S1 = S1 + textBox6.Text + "\n" + textBox5.Text + "\n" + textBox4.Text + "\n" + textBox3.Text + "\n" + "Total Cost == " + textBox1.Text + "\n" ;
            while (listcount < listsize)
            {
                S1 = S1 + listBox1.Items[listcount] + "\n";
                listcount++;
            }

            string s2 = S1 + "\r\n" + firstname + "\r\n" + surname + "\r\n" +  email + "\r\n" + mobile_number + "\r\n" + address;
            Font Font = new Font("Courier New", 14);
            e.Graphics.DrawString(s2, Font, Brushes.Black, 100, 100);
            MessageBox.Show("File Printed Successfully.", "Success");
        }

        private void checkBox1_CheckedChanged_1(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                totalcost = totalcost + 19.99;
                textBox1.Text = Convert.ToString("£" + totalcost);
                listBox1.Items.Add("PC Tuning = £19.99");
            }
        }

        private void checkBox2_CheckedChanged_1(object sender, EventArgs e)
        {
            if (checkBox2.Checked == true)
            {
                totalcost = totalcost + 24.99;
                textBox1.Text = Convert.ToString("£" + totalcost);
                listBox1.Items.Add("Virus Removal = £24.99");
            }
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked == true)
            {
                totalcost = totalcost + 164.99;
                textBox1.Text = Convert.ToString("£" + totalcost);
                listBox1.Items.Add("23 Inch Monitor = 164.99");
            }
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox4.Checked == true)
            {
                totalcost = totalcost + 29.99;
                textBox1.Text = Convert.ToString("£" + totalcost);
                listBox1.Items.Add("Speakers = 29.99");
            }
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //This code opens up the save document texted files.
            DialogResult results;
            results = openFileDialog1.ShowDialog();
            StreamReader rd1 = new StreamReader(openFileDialog1.FileName);
            textBox6.Text = rd1.ReadLine();
            textBox5.Text = rd1.ReadLine();
            textBox4.Text = rd1.ReadLine();
            textBox3.Text = rd1.ReadLine();
            textBox1.Text = rd1.ReadLine();
            while (!rd1.EndOfStream)
            {
                listBox1.Items.Add(rd1.ReadLine());

            }
            rd1.Close();
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //This Code help you save the document files as text file.
            string firstname, surname, email, mobile_number, address;

            firstname = Interaction.InputBox("Customer's First Name", "Customer Details");
            surname = Interaction.InputBox("Customer's Surname", "Customer Details");
            email = Interaction.InputBox("Customer's Email Address", "Customer Details");
            mobile_number = Interaction.InputBox("Customer's Mobile Number", "Customer Details");
            address = Interaction.InputBox("Customer's Address", "Customer Details");

            DialogResult results;
            int listsize = 0, itemswritten = 0;
            results = saveFileDialog1.ShowDialog();
            StreamWriter str1 = new StreamWriter(saveFileDialog1.FileName + ".TXT");
            str1.WriteLine(firstname + " " + surname);
            str1.WriteLine(address);
            str1.WriteLine(email);
            str1.WriteLine(mobile_number);
            str1.WriteLine(textBox1.Text);
            listsize = listBox1.Items.Count;
            while (itemswritten < listsize)
            {
                str1.WriteLine(listBox1.Items[itemswritten]);
                itemswritten++;
            }
            str1.Close();
        }

        private void clearDocumentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //This is for the CheckBoxes to be uncheckedonce used.

            //This is for the RadioButtons to be unchecked once used.
            foreach (Control control in this.Controls)
            {
                if (control.GetType() == typeof(RadioButton))
                {
                    ((RadioButton)control).Checked = false;
                    radioButton6.Checked = false;
                    radioButton7.Checked = false;
                    radioButton8.Checked = false;
                }
            }
            //This is for the ComboBoxes to be Cleared once used.
            foreach (Control control in this.Controls)
            {
                if (control.GetType() == typeof(ComboBox))
                {
                    ((ComboBox)control).Text = " ";
                }
            }
            // To change the radiobutton to false (undselected)
            radioButton6.Checked = false;
            radioButton7.Checked = false;
            radioButton8.Checked = false;
            //To clear the total cost and items boxes.
            listBox1.Items.Clear();
            textBox6.Clear();
            textBox5.Clear();
            textBox4.Clear();
            textBox3.Clear();
            textBox1.Clear();
        }

        //Prints out the Quote for Total Cost and Hardware List.
        private void printQuoteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            printDocument1.Print();
        }

        //Exits the programme.
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you sure you want to leave?", "Leaving", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
            if (dialogResult == DialogResult.Yes)
            {
                Application.Exit();
            }
            else if (dialogResult == DialogResult.No)
            {
                return;
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (textBox2.Visible = true)
            {
                textBox2.Text = "Help Box";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Remove(listBox1.SelectedItem);
            if (listBox1.Items.Count == 0)
            {

            }
        }

        private void Hardware_Click(object sender, EventArgs e)
        {
            textBox2.Visible = false;
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox2_Enter(object sender, EventArgs e)
        {
        }
    }
}
