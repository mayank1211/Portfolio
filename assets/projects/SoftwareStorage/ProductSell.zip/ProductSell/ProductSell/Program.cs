﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductSell
{
    class Program
    {
		class Products
    {
        private double bookQuantity, phoneQuantity, computerQuantity, discount;
        private double grandTotal, bookTotal, phoneTotal, computerTotal, grandTotall;

        public void setBookQuantity(double bookQuantity)
        {
            this.bookQuantity = bookQuantity;
        }
        public void setBookTotal(double bookTotal)
        {
            this.bookTotal = bookTotal;
        }
        public double getBookQuantity()
        {
            return this.bookQuantity;
        }
        public double getBookTotal()
        {
            return this.bookTotal = 5 + this.bookQuantity;
        }
        //Computer properties method
        public void setComputerQuantity(double computerQuantity)
        {
            this.computerQuantity = computerQuantity;
        }
        public void setComputerTotal(double computerTotal)
        {
            this.computerTotal = computerTotal;
        }
        public double getComputerQuantity()
        {
            return this.computerQuantity;
        }
        public double getComputerTotal()
        {
            return this.computerTotal = 699 * this.computerQuantity;
        }
        //Phone properties method
        public void setPhoneQuantity(double phoneQuantity)
        {
            this.phoneQuantity = phoneQuantity;
        }
        public void setPhoneTotal(double phoneTotal)
        {
            this.phoneTotal =  this.phoneTotal;
        }
        public double getPhoneQuantity()
        {
            return this.phoneQuantity;
        }
        public double getPhoneTotal()
        {
            return this.phoneTotal = 450 * this.phoneQuantity;
        }
        public void setDiscount(double discount)
        {
            this.discount =  0.2;
        }
        public double getDisocunt()
        {
            return this.discount;
        }
        public void setTotal(double grandTotal)
        {
            this.grandTotal = grandTotall;
        }
        public double getTotal()
        {
            return this.grandTotal = this.bookTotal + this.computerTotal + this.phoneTotal - this.grandTotall;
        }
        public void setTotall(double grandTotall)
        {
            this.grandTotal = grandTotall;
        }
        public double getTotall()
        {
            return this.grandTotall = (this.bookTotal + this.computerTotal + this.phoneTotal * this.discount) * 0.2;///Need to fix the discount 
        }
	}
        private class Customer
        {
            private string name, address, email, mobileNumber;
            private int houseNumber;

            //Set statement to input following methods.
            public void setName(string name)
            {
                this.name = name;
            }
            public void setAddress(string address)
            {
                this.address = this.houseNumber + " " + address;
            }
            public void setEmail(string email)
            {
                this.email = email;
            }
            public void setHouseNumber(int houseNumber)
            {
                this.houseNumber = houseNumber;
            }
            public void setMobileNumber(string mobileNumber)
            {
                this.mobileNumber = mobileNumber;
            }
            //get statement to output following methods.
            public string getName()
            {
                return this.name;
            }
            public string getAddress()
            {
                return this.address;
            }
            public string getEmail()
            {
                return this.email;
            }
            public int getHouseNumber()
            {
                return this.houseNumber;
            }
            public string getMobileNumber()
            {
                return this.mobileNumber;
            }
        }

        static void Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.Cyan;

            Customer customer = new Customer(); // This will create new customer/object using the class Customer.
            Products pro = new Products();

            bool go = true;
            bool p = true;
            while (go)
                try
                {
                    Console.WriteLine("\n\tWelcome to the ProductSell!\n");
                    Console.WriteLine("\t[1] New User");
                    Console.WriteLine("\t[2] Search Product");
                    Console.WriteLine("\t[3] Invoice");
                    Console.WriteLine("\t[4] Help Guide");
                    Console.WriteLine("\t[5] Quit");
                    Console.Write("\n\tSelect from menu: ");

                    int menyVal = Convert.ToInt32(Console.ReadLine());
                    int i = 0;

                    switch (menyVal)
                    {
                        case 1:
                            Console.WriteLine("\n\tEnter your Full Name\n");
                            customer.setName(Console.ReadLine());

                            Console.WriteLine("\n\tEnter your House Number\n");
                            customer.setHouseNumber(int.Parse(Console.ReadLine()));

                            Console.WriteLine("\n\tEnter your Address/Street\n");
                            customer.setAddress(Console.ReadLine());

                            Console.WriteLine("\n\tEnter your Email Address\n");
                            customer.setEmail(Console.ReadLine());

                            Console.WriteLine("\n\tEnter your Mobile Number\n");
                            customer.setMobileNumber(Console.ReadLine());

                            Console.Clear();


                            break;

                        case 2:

                            Console.WriteLine("\n\t [1] to buy C# book\n");
                            Console.WriteLine("\n\t [2] to buy Dell computer\n");
                            Console.WriteLine("\n\t [3] to buy iPhone\n");
                            if (p = true)
                                try
                                {
                                    int promenu = Convert.ToInt32(Console.ReadLine());
                                    int x = 0;    

                                    switch (promenu)
                                    {
                                        case 1:
                                            Console.WriteLine("\n\tEach C# book costs £5\n");
                                            Console.WriteLine("\n\tEnter Book Quantity\n");
                                            pro.setBookQuantity(int.Parse(Console.ReadLine()));

                                            break;

                                        case 2:
                                            Console.WriteLine("\n\teach Dell Computer costs £699\n");
                                            Console.WriteLine("\n\tEnter Dell computer Quantity\n");
                                            pro.setComputerQuantity(int.Parse(Console.ReadLine()));


                                            break;
                                        case 3:
                                            Console.WriteLine("\n\tEach iPhone costs 450\n");
                                            Console.WriteLine("\n\tEnter Phone Quantity\n");
                                            pro.setPhoneQuantity(int.Parse(Console.ReadLine()));
                                            p = false;
                                            break;
                                            Console.Clear();
                                    }
                                }
                                catch
                                {
                                    Console.WriteLine("\tChoose from menu 1 - 3");
                                }
                            break;

                        case 3:
                            Console.Clear();
                            Console.WriteLine("\n\t   Your Invoice  \n");
                            Console.WriteLine("\n\tName : " + customer.getName() + "\n");
                            Console.WriteLine("\n\tAddress : " + customer.getAddress() + "\n");
                            Console.WriteLine("\n\tMobile : " + customer.getMobileNumber() + "\n");
                            Console.WriteLine("\n\tEmail : " + customer.getEmail() + "\n");
                            Console.WriteLine("\n\tBook Cost: " + ("Each Book £4 ") +" "+ pro.getBookTotal() + " | Book Quantity: " + pro.getBookQuantity() + "\n");
                            Console.WriteLine("\n\tPhone Cost: " + ("Each Phone £450")+ + pro.getPhoneTotal() + " | Phone Quantity: " + pro.getPhoneQuantity() + "\n");
                            Console.WriteLine("\n\tComputer Cost: " + ("Each Computer £699")+" " + pro.getComputerTotal() + " | Computer Quantity: " + pro.getComputerQuantity() + "\n");
                            Console.WriteLine("\n\tDiscount Applied of: £" + pro.getTotall() + "\n");
                            Console.WriteLine("\n\tTotal Cost: £" + pro.getTotal() + "\n");
                            Console.WriteLine("\n\tYour order is on its way! " + customer.getName() + "\n");
                            Console.ReadKey();
                            Console.Clear();
                            break;

                        default:
                            Console.WriteLine("\tChoose from menu 1 - 4");
                            break;

                        case 4:
                            Console.Clear();
                            Console.WriteLine("\n\tHi there, Welcome! ");
                            Console.WriteLine("\n\tFirst thing is that we require your details for invoice.");
                            Console.WriteLine("\n\tIf your new then press 1 from the main menu and complete the shown steps and make sure the details is correct.\n");
                            Console.WriteLine("\n\tSecondly, simply press 2 and select the wanted product and the quantity.\n");
                            Console.WriteLine("\n\tWhen you ready, simply press 3 from the main menu to get your invoice with total cost.\n");
                            Console.WriteLine("\n\tOnce you finished simply press 5 to exit the application.\n");
                            Console.WriteLine("\n\tThank You.\n");
                            break;

                        case 5:
                            go = false;
                            break;
                    }
                }
                catch
                {
                    Console.WriteLine("\tChoose from menu 1 - 4");
                }
        }
    }
}
